#Our Additions 
**We are both interested in photography so it made sense to make a site related to
photography, so we created a whole new Kodak website with Berfin.**

-Completely changed the color profile;( #ffb700  kodak yellow
#eb0504 kodak red) \

-Added actual videos to href in the hero section\

-Added a photo I took with the 500T film on my camera as a background\

Removed the background of a film roll online and put it on the hero section\

Created a bestsellers division with real film names and info\

Changed the box shadows\

Made a youtube channel section with a new photo as a background\

Also made the button for youtube open Kodak's youtube channel\

Added a linear gradient  on the youtube channel section\

Created a mail list part with new colors and text.\

Added another column just to see how things change named "Films shot on Kodak"
Linked all of the trailer links to those movie names, dont forget to click on them, it will open a player. \

Deleted some of the dropdown elements and replaced them with actual categories taken from Kodak's current website\

Changed the footer, replaced the address with Kodak's real address;\

As you probably remember from our class we found the source:
* Template Name: Arsha - v4.7.1
* Template URL: https://bootstrapmade.com/arsha-free-bootstrap-html-template-corporate/
* Author: BootstrapMade.com
* License: https://bootstrapmade.com/license/ \
